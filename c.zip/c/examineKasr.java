package com.Gita2.homewok.c;

public class examineKasr {
    public static void main(String[] args) {
        Kasr a = new Kasr();
        a.surat = 18;
        a.maxraj = 4;
        System.out.println(a.show());
    }
}
