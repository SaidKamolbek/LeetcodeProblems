package com.Gita2.homewok.c;

public class Kasr {
    int surat;
    int maxraj;

    String show() {
        int a = surat;
        int b = maxraj;
        if (a % b == 0) return a / b + "";
        while (a != 0) {
            int q = a;
            a = b % a;
            b = q;
        }
        return surat / b + "/" + maxraj / b;
    }
}
