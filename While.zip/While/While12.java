package com.GitaEducation.While;

import java.util.Scanner;

public class While12 { // xato
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int k=1,s=0;
        do{
            s+=k;
            k++;
        }
        while (n>s+k);
        System.out.println(--k);
        System.out.println(s);


    }
}
