package com.GitaEducation.While;

import java.util.Scanner;

public class While7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n= input.nextInt();
        int k=1;
        while (k*k<=n){
            k++;
        }
        System.out.println(k);
    }
}
