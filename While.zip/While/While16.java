package com.GitaEducation.While;

import java.util.Scanner;

public class While16 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double S = 0, a = 10, p = input.nextDouble();
        int k = 1;
        while (S < 200) {
            a *= (1 + p / 100);
            S += a;
            k++;
        }
        System.out.println("kun: " + k);
        System.out.printf("%.2f %n",S);
    }
}
