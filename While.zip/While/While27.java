package com.GitaEducation.While;

import java.util.Scanner;

public class While27 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int f1 = 1, f2 = 1;
        int f3 = 0,k=2;
       //   System.out.print(f1+" "+f2+" ");
        while (f3 < n) {
            f3 = f1 + f2;
            f1 = f2;
            f2 = f3;
            k++;
     //         System.out.print(f3+" ");
        }if (n==f3) System.out.println(k);
        else System.out.println("fibonachi emas");
    }
}
