package com.GitaEducation.While;

import java.util.Scanner;

public class While21 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int t = 0, k = 0;
        while (n >= 1) {
            k = n % 10;
            n /= 10;
            if (k%2==1){
                System.out.println(" toq son bor");break;
            }
        } if (k%2==0) System.out.println("top son y`oq");
    }
}
