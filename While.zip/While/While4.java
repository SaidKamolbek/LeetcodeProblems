package com.GitaEducation.While;

import java.util.Scanner;

public class While4 {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int n= input.nextInt();
        int s=1;
       while (s<n){
           s*=3;
       }if (s==n) System.out.println("3ni darajasi");
       else System.out.println("3ni darajasi emas");

    }
}
