package com.GitaEducation.While;

import java.util.Scanner;

public class While10 {
    public static void main(String[] args) {
        Scanner input =new Scanner(System.in);
        int n= input.nextInt();
        int k=0, s=1;

        while (s<=n){
            s*=3;
            k++;
        };
        System.out.println(--k);
    }
}
