package com.GitaEducation.While;

import java.util.Scanner;

public class While15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double s = in.nextDouble();
        double p = in.nextDouble();
        double Sum = 0;
        int k = 0;
        Sum = s;
        while (Sum <= 2 * s) {
            Sum *= (1 + p / 100);
            k++;
        }
        System.out.println(k + " oyda");
        System.out.printf("%.2f %n", Sum);
    }
}
