package com.GitaEducation.While;

import java.util.Scanner;

public class While13 {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        double a= input.nextDouble();
        double k=1 , s=0;
        while (s<a){
            s+=1/k;
            k++;
        }
        System.out.println(k);
        System.out.printf("%.2f %n",s);
    }
}
