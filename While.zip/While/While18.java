package com.GitaEducation.While;

import java.util.Scanner;

public class While18 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int m = 0;
        int k = 0;
        while (n >= 1) {
            m=n%10;
            n/=10;
            System.out.print(m+" ");
        }
    }
}
