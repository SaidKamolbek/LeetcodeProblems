package com.GitaEducation.While;

import java.util.Scanner;

public class While14 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double a= input.nextDouble();
        double k=1 , s=0;
        while (s<a-1/k){
            s+=1/k;
            k++;
        }
        System.out.println(--k);
        System.out.printf("%.2f %n",s);

    }
}

