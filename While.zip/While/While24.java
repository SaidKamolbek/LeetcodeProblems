package com.GitaEducation.While;

import java.util.Scanner;

public class While24 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int f1 = 1, f2 = 1;
        int f3 = 0;
        // System.out.print(f1+" "+f2+" ");
        while (f3 < n) {
            f3 = f1 + f2;
            f1 = f2;
            f2 = f3;
          //   System.out.print(f3+" ");
        }
        if (f3 == n) System.out.println("bor");
        else System.out.println("yo`q");
    }
}
