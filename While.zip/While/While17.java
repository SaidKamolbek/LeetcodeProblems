package com.GitaEducation.While;

import java.util.Scanner;

public class While17 {
    public static void main(String[] args) {
        Scanner input =new Scanner(System.in);
        int n= input.nextInt();
        int m= input.nextInt();
        int k=0;
       while (m<n){
            n-=m;
            k++;
        }
        System.out.println(k);
        System.out.println(n);
    }
}
