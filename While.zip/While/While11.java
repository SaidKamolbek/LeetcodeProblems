package com.GitaEducation.While;

import java.awt.*;
import java.util.Scanner;

public class While11 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int n= input.nextInt();
        int s=0, k=0;
        while (s<n){
            s+=k;
            k++;
        }
        System.out.println(s);
        System.out.println(k);
    }
}
