package com.GitaEducation.While;

import java.util.Scanner;

public class While22 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int t = 0, k = 1;
        while (k <= n) {
            if (n%k==0)t++;
            k++;
        }if (t==2) System.out.println("tub son");
        else System.out.println("tub emas");
    }
}
