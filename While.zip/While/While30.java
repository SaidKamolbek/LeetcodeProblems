package com.GitaEducation.While;

import java.util.Scanner;

public class While30 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();
        int en = 0, boy = 0;
        while (a >= c) {
            a -= c;
            en++;
        }
        while (b>c){
            b-=c;
            boy++;
        }
        System.out.println(en*boy+" ta sigadi");
    }
}
