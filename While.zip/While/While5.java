package com.GitaEducation.While;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.util.Scanner;

public class While5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n= input.nextInt();
        int k=0;
        int d=1;
        while (d<n){
            d*=2;
            k++;
        }if (d==n) System.out.println(k);
        else System.out.println("2ni darajasi emas");
    }
}

