package com.GitaEducation.While;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.util.Scanner;

public class While9 {
    public static void main(String[] args) {
        Scanner input =new Scanner(System.in);
        int n= input.nextInt();
        int k=0, s=1;

      while (s<=n){
          s*=3;
          k++;
      };
        System.out.println(k);
    }
}
