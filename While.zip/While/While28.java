package com.GitaEducation.While;

import java.util.Scanner;

public class While28 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double e = input.nextDouble();
        double q = 0, a = 2, k = 1;
        while (Math.abs(a - q) > e) {
            q = a;
            a = 2 + 1 / a;
            k++;
        }
        System.out.println(k);
        System.out.println(q + " " + a);
    }
}

