package com.GitaEducation.While;

import java.util.Scanner;

public class While3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n= input.nextInt();
        int k= input.nextInt();
        int b=0;
        while (n>k){
            n-=k;
            b++;
        }
        System.out.println(b);
        System.out.println(n);
    }
}
