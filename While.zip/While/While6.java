package com.GitaEducation.While;

import java.util.Scanner;

public class While6 {
    public static void main(String[] args) {
        Scanner iput= new Scanner(System.in);
        int n= iput.nextInt();
        int i=0, s=1;
        while (n-i>1){
            s*=(n-i);
            i+=2;
        }
        System.out.println(s);
    }
}
