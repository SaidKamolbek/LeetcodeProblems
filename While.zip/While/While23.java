package com.GitaEducation.While;

import java.awt.*;
import java.util.Scanner;

public class While23 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a= input.nextInt();
        int b= input.nextInt();
       while (a!=0){
           int q=a;
           a=b%a;
           b=q;
     //      System.out.println(a+" "+b);
       }
        System.out.println(b);
    }
}
