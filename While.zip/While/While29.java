package com.GitaEducation.While;

import java.util.Scanner;

public class While29 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double e = input.nextDouble();
        double a1 = 1, a2 = 2, a = 0, q = 0;
        int k = 2;

        while (Math.abs(a - a1) > e) { // a-a2 desam ular teng bo`p qoladi , a1 esa a2 ni qiymatini o`zlashitirgan
            a = (a1 + 2 * a2) / 3;
            a1 = a2;
            a2 = a;
            k++;
        }
        System.out.println(k);
        System.out.println(a + " " + a2);
    }
}
