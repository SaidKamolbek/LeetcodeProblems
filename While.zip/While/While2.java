package com.GitaEducation.While;

import java.util.Scanner;

public class While2 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int a= input.nextInt();
        int b= input.nextInt();
        int s=0;
        while (a>=b){
            a-=b;
            s++;
        }
        System.out.println(s);
    }
}
