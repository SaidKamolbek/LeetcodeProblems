package com.GitaEducation.FunSimple;

import java.awt.*;
import java.util.Scanner;

public class FN4 {
    static void Triangle(double a){
        double S=Math.sqrt(3)/4*a*a;
        double P=3*a;
        System.out.printf("\nyuzasi: %.2f \nperimetri: %.2f",S,P);
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int A= input.nextInt();
        int b= input.nextInt();
        int c= input.nextInt();
        Triangle(A);
        Triangle(b);
        Triangle(c);
    }
}
