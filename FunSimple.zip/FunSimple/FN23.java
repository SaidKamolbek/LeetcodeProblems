package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN23 {
    static int Quarter(int x, int y) {
        if (x > 0 && y > 0) return 1;
        else if (x < 0 && y > 0) return 2;
        else if (x < 0 && y < 0) return 3;
        else if (x > 0 && y < 0) return 4;
        return 0;
    }

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int x= input.nextInt();
        int y= input.nextInt();
        int javob=Quarter(x,y);
        System.out.println(javob);
    }
}
