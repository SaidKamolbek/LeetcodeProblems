package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN1 {
   static int PowerA3(int a){
       return a*a*a;
   }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int A= input.nextInt();
        int B= input.nextInt();
        int C= input.nextInt();
        double E= input.nextDouble();
        double D= input.nextDouble();

        System.out.println(PowerA3(A));
        System.out.println(PowerA3(B));
        System.out.println(PowerA3(C));
        System.out.println(PowerA3(E));
        System.out.println(PowerA3(D));
            }
            static double PowerA3(double a){
       return a*a*a;
            }

}
