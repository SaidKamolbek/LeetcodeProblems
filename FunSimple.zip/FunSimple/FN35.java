package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN35 {
    static int Fact2(int N) {
        if (N % 2 == 1) {
            if (N <= 1) return 1;
            else return N * Fact2(N - 2);
        } else {
            if (N <= 2) return 2;
            else return N * Fact2(N - 2);
        }
    }

    public static void main(String[] args) {
        int N1 = 5, N2 = 6, N3 = 7;
        System.out.println(Fact2(N1));
        System.out.println(Fact2(N2));
        System.out.println(Fact2(N3));
    }
}
