package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN19 {
    static double YUza(double a, double b) {
        return Math.abs(a * a - b * b) * Math.PI;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double a = input.nextDouble();
        double b = input.nextDouble();
        double S = YUza(a, b);
        System.out.printf("%.2f",S);
    }
}
