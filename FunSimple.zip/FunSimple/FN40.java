package com.GitaEducation.FunSimple;

public class FN40 {
    static double Exp1(double x, double e) {
        double Sum = x;
        double Q = 1, P = 1;
        int i = 1;
        while (Q / P > e) {
            P *= i;
            Q *= x;
            Sum += Q / P;
            i++;
        }
        return Sum;
    }

    public static void main(String[] args) {
        double x = 1, e = 0.01;
        double Sum = Exp1(x, e);
        System.out.println(Sum);
    }
}
