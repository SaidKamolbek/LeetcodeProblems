package com.GitaEducation.FunSimple;

public class FN38 { // kommentariya ichidagi kodni korsatish karak 25-qator
    static double Power2(double A, int n) {
        double p = 1;
        if (n == 0) return 1;
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                p *= A;
            }
            return p;
        } else {
            for (int i = 0; i < -n; i++) {
                p *= 1 / A;
            }
        }
        return p;
    }

    public static void main(String[] args) {
        double A = 2.5;
        int n1 = 0, n2 = 3, n3 = -3;
        System.out.printf("%f \n%f \n%f", Power2(A, n1), Power2(A, n2), Power2(A, n3));
    }
//    static double Power22(double a, int n){
//      int p=1;
//        if (n==0)return 1;
//       while (n>0){
//            p*=a;
//            n--;
//        }return p;
//        if (n<0) {
//            return (1/Power22(a,n*-1));
//        }
//    }
}
