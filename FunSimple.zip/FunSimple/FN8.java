package com.GitaEducation.FunSimple;

import java.awt.image.AreaAveragingScaleFilter;
import java.util.Scanner;

public class FN8 {
    static int AddRightDigit(int a,int R){
        return a*10+R;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("a= ");
        int a= input.nextInt();
        System.out.print("R= ");
        int R= input.nextInt();
        int S=AddRightDigit(a,R);
        System.out.println(S);
    }
}
