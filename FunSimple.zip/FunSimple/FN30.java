package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN30 {
    static int DigitN(int N, int K) {
        int q = 0, S = N, p = 0;
        while (S > 0) {
            S /= 10;
            q++;
        }
        while (p < q - K) {
            N /= 10;
            p++;
        }
        if (K < q)
            return N % 10;
        else return 0;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int N = input.nextInt();
        int k = input.nextInt();
        int w = DigitN(N, k);
        System.out.println(w);
    }
}
