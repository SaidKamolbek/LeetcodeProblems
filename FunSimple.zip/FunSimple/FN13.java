package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN13 {
    static void Sortdec(int a, int b, int c) {
        int q = a + b + c, t = a;
        a = Math.max(a, Math.max(b, c));
        c = Math.min(t, Math.min(b, c));
        b = q - a - c;
        System.out.print(a + " " + b + " " + c);
    }

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();
        Sortdec(a, b, c);
    }
}
