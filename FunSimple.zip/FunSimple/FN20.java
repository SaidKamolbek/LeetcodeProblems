package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN20 {
    static double TriangleP(double a, double b){
        double c=Math.sqrt(a*a+b*b);
        return a+b+c;
    }

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int a= input.nextInt();
        int b= input.nextInt();
        double S=TriangleP(a,b);
        System.out.println(S);
    }
}
