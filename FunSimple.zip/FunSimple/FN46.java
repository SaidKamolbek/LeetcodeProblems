package com.GitaEducation.FunSimple;

public class FN46 {
    public static void main(String[] args) {
        int a = 24, b = 100, c = 120, d = 80;
        System.out.println(EKUB(a, b));
        System.out.println(EKUB(a, c));
        System.out.println(EKUB(a, d));
    }

    static int EKUB(int a, int b) {
        while (a != 0) {
            int q = a;
            a = b % a;
            b = q;
        }
        return b;
    }
}
