package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN25 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();
        boolean t1 = IsSquare(a);
        boolean t2 = IsSquare(b);
        boolean t3 = IsSquare(c);
        System.out.println(t1);
        System.out.println(t2);
        System.out.println(t3);
    }

    static boolean IsSquare(double k) {
        return k == (int)Math.sqrt(k)*Math.sqrt(k);
    }
}
