package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class Fn53 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int y = input.nextInt();
        int m = input.nextInt();
        System.out.println(Monthdays(m, y));
    }

    static int Monthdays(int m, int y) {

        switch (m) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            case 2: {
                if (IsLeapYear(y)) return 29;
                return 28;
            }
        }
        return 0;
    }

    static boolean IsLeapYear(int y) {

        return y % 400 == 0 || (y % 4 == 0 && y % 100 != 0);
    }
}
