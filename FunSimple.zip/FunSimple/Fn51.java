package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class Fn51 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int hour = input.nextInt();
        int minut = input.nextInt();
        int sek = input.nextInt();
        int T = input.nextInt();
        System.out.println(LncTime(hour, minut, sek, T));
    }

    static String LncTime(int h, int m, int s, int T) {
        int t = h * 3600 + m * 60 + s + T;
        return TimeToHMS(t);
    }

    static String TimeToHMS(int T) {
        int H;
        H = T / 3600;
        return T / 3600 + ":" + (T / 60 - H * 60) + ":" + T % 60;
    }
}
