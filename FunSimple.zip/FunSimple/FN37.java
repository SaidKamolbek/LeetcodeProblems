package com.GitaEducation.FunSimple;

public class FN37 {
    static double Power1(double A, int B) {
        int i = 0;
        double P = 1;
        while (i < B) {
            P *= A;
            i++;
        }
        return P;
    }

    public static void main(String[] args) {
        double A1 = 2.5, A2 = 3.145, A3 = 6.3214;
        int B = 3;
        System.out.printf("\n%f \n%f \n%f ", Power1(A1, B), Power1(A2, B), Power1(A3, B));
    }
}
