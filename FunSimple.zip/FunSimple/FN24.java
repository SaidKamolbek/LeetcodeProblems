package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN24 {
    static boolean Even(int k){
        boolean t=true;
        if (k%2==1)t=false;
        return t;
    }

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int a= input.nextInt();
        int b= input.nextInt();
        int c= input.nextInt();
        boolean t1=Even(a);
        boolean t2=Even(b);
        boolean t3=Even(c);
        System.out.println(t1+" "+t2+" "+t3);
    }
}
