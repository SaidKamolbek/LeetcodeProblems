package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN29 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            int a= input.nextInt();
            int q=DigitCount(a);
            System.out.println(q);
        }
    }

    static int DigitCount(int a) {
        int q = 0;
        while (a >= 1) {
            a /= 10;
            q++;
        }
        return q;
    }
}
