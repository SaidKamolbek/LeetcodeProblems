package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class Fn59 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double x1 = input.nextDouble();
        double y1 = input.nextDouble();
        double x2 = input.nextDouble();
        double y2 = input.nextDouble();
        double x3 = input.nextDouble();
        double y3 = input.nextDouble();
        System.out.println(DIst(x1, y1, x2, y2, x3, y3));
    }

    static double DIst(double Px, double Py, double x2, double y2, double x3, double y3) {
        double H = 2 * Area(Px, Py, x2, y2, x3, y3) / Length(x2, y2, x3, y3);
        return H;
    }

    static double Area(double x1, double y1, double x2, double y2, double x3, double y3) {
        double a = Length(x1, y1, x2, y2);
        double b = Length(x3, y3, x2, y2);
        double c = Length(x1, y1, x3, y3);
        double P = Perim(x1, y1, x2, y2, x3, y3);
        double S = Math.sqrt(P / 2 * (P / 2 - a) * (P / 2 - b) * (P / 2 - c));
        return S;
    }

    static double Perim(double x1, double y1, double x2, double y2, double x3, double y3) {
        double a = Length(x1, y1, x2, y2);
        double b = Length(x3, y3, x2, y2);
        double c = Length(x1, y1, x3, y3);
        return a + b + c;
    }

    static double Length(double x1, double y1, double x2, double y2) {
        return Math.sqrt((x2 - x1) * (x2 - x1) + (y1 - y2) * (y1 - y2));
    }
}
