package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN14 {
    static void ShiftRight(int a, int b, int c) {
        int p = a;
        a = b;
        b = c;
        c = p;
        System.out.print(a + " " + b + " " + c);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();
        ShiftRight(a, b, c);
    }
}
