package com.GitaEducation.FunSimple;

public class FN45 {
    public static void main(String[] args) {
        double x = 0.5, a = 6, e1 = 0.1, e2 = 0.01, e3 = 0.001;
        System.out.println(power4(x, a, e1));
        System.out.println(power4(x, a, e2));
        System.out.println(power4(x, a, e3));
        System.out.println(Math.pow(1+x,a));
    }

    static double power4(double x, double a, double e) {
        double sum = 1, q = 1, p = 1, b = 1;
        int t = 1;
        while (b * p * q > e) {
            p = Fact(t);
            b *= a;
            q *= x;
            sum += b * q / p;
            t++;
            a--;
        }
        return sum;
    }

    static int Fact(int N) {
        if (N <= 1) return 1;
        else return N * Fact(N - 1);
    }
}
