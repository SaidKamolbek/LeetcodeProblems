package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN21 {
    static int SumRAnge(int a, int b) {
        int sum = 0;
        if (a < b) {
            for (int i = a + 1; i < b; i++) {
                sum += i;
            }return sum;
        }else return 0;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a= input.nextInt();
        int b= input.nextInt();
        int sum=SumRAnge(a,b);
        System.out.println(sum);
    }
}
