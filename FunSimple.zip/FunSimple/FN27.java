package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN27 {
    static boolean Ispower(int k, int n) {
        int d = 1;
        while (d < k) d *= n;
        return d == k;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("n: ");
        int n = input.nextInt();
        int t=0;
        for (int i = 0; i < 5; i++) {
            int k= input.nextInt();
            if (Ispower(k,n))t++;
        }
        System.out.println(t);

    }
}
