package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN34 {
    static int Fact(int N) {
        if (N <= 1) return 1;
        else return N * Fact(N - 1);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int N = input.nextInt();
        int Fact = Fact(N);
        System.out.println(Fact);
    }
}
