package com.GitaEducation.FunSimple;

public class FN52 {
    public static void main(String[] args) {
        int y1 = 2020, y2 = 300, y3 = 1000, y4 = 2000;
        System.out.println(IsLeapYear(y1));
        System.out.println(IsLeapYear(y2));
        System.out.println(IsLeapYear(y3));
        System.out.println(IsLeapYear(y4));
    }

    static boolean IsLeapYear(int y) {
        return y % 400 == 0 || (y % 4 == 0 && y % 100 != 0);
    }
}
