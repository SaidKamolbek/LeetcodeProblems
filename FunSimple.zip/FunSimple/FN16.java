package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN16 {
    static int Ishora(int a){
        if (a>0)return 1;
        else if (a<0)return -1;
        else return 0;
    }

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int a=input.nextInt();
        int b=Ishora(a);
        System.out.println(b);
    }
}
