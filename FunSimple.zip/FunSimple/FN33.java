package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN33 {
    static double RadToDeg(double R) {
        return R * 180 / Math.PI;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double d = input.nextInt();
        double deg = RadToDeg(d);
        System.out.println(deg);
    }
}
