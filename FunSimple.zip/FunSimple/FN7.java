package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN7 {
    static void InvertDIgit(int a) {
        while (a > 0) {
            int b = a % 10;
            a /= 10;
            System.out.print(b+" ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a= input.nextInt();
        int b= input.nextInt();
        int c= input.nextInt();
        InvertDIgit(a);
        InvertDIgit(b);
        InvertDIgit(c);
    }
}
