package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN2 {
    static void PowerA234(double a){
        System.out.println("2-darajasi: "+a*a);
        System.out.println("3-darajasi: "+a*a*a);
        System.out.println("4-darajasi: "+a*a*a*a);

    }
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int A= input.nextInt();
        int B= input.nextInt();
        int C= input.nextInt();
        PowerA234(A);
        PowerA234(B);
        PowerA234(C);
    }
}
