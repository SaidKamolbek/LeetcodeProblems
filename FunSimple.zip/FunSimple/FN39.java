package com.GitaEducation.FunSimple;

public class FN39 {  // ishlab bilmadim
    static double Power1(double A, int B) {
        int i = 0;
        double P = 1;
        while (i < B) {
            P *= A;
            i++;
        }
        return P;
    }

    static double Power2(double A, int n) {
        double p = 1;
        if (n == 0) return 1;
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                p *= A;
            }
            return p;
        } else {
            for (int i = 0; i < -n; i++) {
                p *= 1 / A;
            }
        }
        return p;
    }

    public static void main(String[] args) {
        double A = 2.5, N = 0, M = 3.5, K = 3;
        System.out.println(power3(A, N));
        System.out.println(power3(A, M));
        System.out.println(power3(A, K));
    }

    static double power3(double A, double N) {
        if (N == (int) N) {
            Power1(A, (int) N);
        }
        return Power2(A, (int) N);
    }
}