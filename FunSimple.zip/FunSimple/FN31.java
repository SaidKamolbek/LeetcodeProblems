package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN31 {
    static boolean IsPolindrom(int N) {
        int q, Sum = 0, temp = N;
        while (N > 0) {
            q = N % 10;
            Sum = Sum * 10 + q;
            N /= 10;
        }
        return Sum == temp;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int N = input.nextInt();
        Boolean t = IsPolindrom(N);
        System.out.println(t);
    }
}
