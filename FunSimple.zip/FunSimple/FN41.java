package com.GitaEducation.FunSimple;

public class FN41 {

    public static void main(String[] args) {
        double x = 2, e = 0.001;
        System.out.println(sin1(x, e));
        System.out.println(Math.sin(x));
    }

    static double sin1(double x, double e) {
        double P = 1, Sum = 0, Q = 1;
        int i = 0;
        while (Q / P > e) {
            Q = Power2(x, 2 * i + 1);
            P = Fact(2 * i + 1);
            Sum += Q / P * Math.pow(-1, i);
            i++;
        }
        return Sum;
    }


    static double Power2(double A, int n) {
        double p = 1;
        if (n == 0) return 1;
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                p *= A;
            }
            return p;
        } else {
            for (int i = 0; i < -n; i++) {
                p *= 1 / A;
            }
        }
        return p;
    }

    static int Fact(int N) {
        if (N <= 1) return 1;
        else return N * Fact(N - 1);
    }
}
