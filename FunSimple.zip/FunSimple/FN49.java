package com.GitaEducation.FunSimple;

public class FN49 {
    public static void main(String[] args) {
        int a = 24, b = 100, c = 120, d = 80;
        System.out.println(EKUB3(a, b, c));
        System.out.println(EKUB3(a, c, d));
        System.out.println(EKUB3(a, b, d));
    }

    static int EKUB3(int a, int b, int c) {
        int q = EKUB(a, EKUB(b, c));
        return q;
    }

    static int EKUB(int a, int b) {
        while (a != 0) {
            int q = a;
            a = b % a;
            b = q;
        }
        return b;
    }

}
