package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class Fn54 {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int day= input.nextInt();
        int month= input.nextInt();
        int year= input.nextInt();
        System.out.println(PrevDate(day,month,year));
    }

    static String PrevDate(int d, int m, int y) {
        int daysInMonth = Monthdays(m, y);
        if (daysInMonth < d) return "bunday sana yo`q";
        else if (d != 1) return "" + (d - 1) + "/" + m + "/" + y;
        else {
            if (m==1){
                y--;
                m=12;
            }else m--;
            return ""+Monthdays(m,y)+"/"+m+"/"+y;
        }
    }

    static int Monthdays(int m, int y) {

        switch (m) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
            case 2: {
                if (IsLeapYear(y)) return 29;
                return 28;
            }
        }
        return 0;
    }

    static boolean IsLeapYear(int y) {

        return y % 400 == 0 || (y % 4 == 0 && y % 100 != 0);
    }
}
