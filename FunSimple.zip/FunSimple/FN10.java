package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN10 {
    static void Swap(int a, int b) {
        int c = a;
        a = b;
        b = c;
        System.out.println(a + " " + b);
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int A = input.nextInt();
        int B = input.nextInt();
        int C = input.nextInt();
        int D = input.nextInt();
        Swap(A, B);
        Swap(C, D);

    }
}
