package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN12 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();
        Sortlnc3(a, b, c);
    }

    static void Sortlnc3(int a, int b, int c) {
        int q = a + b + c, p = b, t = c;
        c = Math.max(a, Math.max(b, c));
        a = Math.min(a, Math.min(b, t));
        b = q - a - c;
        System.out.print(a + " " + b + " " + c);
    }
}
