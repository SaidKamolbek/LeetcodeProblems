package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN15 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();
        ShiftLeft(a, b, c);
    }

    static void ShiftLeft(int a, int b, int c) {
        int p = c;
        c = b;
        b = a;
        a = p;
        System.out.print(a + " " + b + " " + c);
    }
}
