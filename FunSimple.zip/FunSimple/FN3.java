package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN3 {
    static void MEAN(double x, double y){
        double S=(x+y)/2;
     double G=Math.sqrt(x*y);
        System.out.println(S);
        System.out.printf("%.2f",G);
        System.out.println("\n ******** ");
    }

    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        int A= inp.nextInt();
        int B= inp.nextInt();
        int C= inp.nextInt();
        MEAN(A,B);
        MEAN(A,C);
        MEAN(B,C);
    }

}
