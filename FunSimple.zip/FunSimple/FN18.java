package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN18 {
    static double Yuza(double a){
        return a*a*Math.PI;
    }
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        double a= input.nextInt();
        double S=Yuza(a);
        System.out.printf("%.2f",S);
    }
}
