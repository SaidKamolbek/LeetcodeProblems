package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class Fn50 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int T = input.nextInt();
        System.out.println(TimeToHMS(T));
    }

    static String TimeToHMS(int T) {
        int H;
        H = T / 3600;
        return T / 3600 + ":" + (T / 60 - H * 60) + ":" + T % 60;
    }
}
