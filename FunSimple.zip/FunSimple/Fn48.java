package com.GitaEducation.FunSimple;

public class Fn48 {
    public static void main(String[] args) {
        int a = 24, b = 100, c = 120, d = 80;
        System.out.println(EKUK(a, b));
        System.out.println(EKUK(a, c));
        System.out.println(EKUK(a, d));
    }

    static int EKUK(int a, int b) {
        int q = a * b / EKUB(a, b);
        return q;
    }

    static int EKUB(int a, int b) {
        while (a != 0) {
            int q = a;
            a = b % a;
            b = q;
        }
        return b;
    }

}
