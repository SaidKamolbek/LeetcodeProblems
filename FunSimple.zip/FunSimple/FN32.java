package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN32 {
    static double DegToRad(double D) {
        return D*Math.PI/180;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double d= input.nextInt();
        double gra=DegToRad(d);
        System.out.println(gra);
    }
}
