package com.GitaEducation.FunSimple;

public class FN36 {
    static int Fib_1(int N) {
        if (N == 1 || N == 2) return 1;
        return Fib_1(N - 1) + Fib_1(N - 2);
    }

    public static void main(String[] args) {
        int N1 = 5, N2 = 6, N3 = 10;
        Fib_2(20);
        System.out.printf("\n%d \n%d \n%d", Fib_1(N1), Fib_1(N2), Fib_1(N3));
    }

    static void Fib_2(int N) {
        int a, b, s, n;
        a = b = 1;
        for (n = 1; n <= N; n++) {
            System.out.print(a + " ");
            s = a + b;
            a = b;
            b = s;
        }
    }
}
