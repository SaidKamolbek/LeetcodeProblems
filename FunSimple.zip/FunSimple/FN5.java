package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN5 {
    static void RectPS(int x1, int x2, int y1, int y2) {
        int a=Math.abs(x1-x2);
        int b=Math.abs(y1-y2);
        int S=a*b;
        int P=(a+b)*2;
        System.out.printf("yuzasi: %d \nperimetri: %d",S,P);
    }

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int x1= input.nextInt();
        int y1= input.nextInt();
        int x2= input.nextInt();
        int y2= input.nextInt();
        RectPS(x1,x2,y1,y2);
    }
}
