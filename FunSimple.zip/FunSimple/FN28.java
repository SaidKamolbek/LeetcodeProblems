package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN28 {
    static boolean IsPrime(int N) {
        int i = 1, t = 0;
        while (i*i < N) {
            if (N % i == 0) t++;
            i++;
        }
        return t == 1;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("nechta: ");
        int k = input.nextInt();
        int s = 0;
        for (int i = 0; i < k; i++) {
            int n = input.nextInt();
            if (IsPrime(n)) s++;
        }
        System.out.println(s);
    }
}
