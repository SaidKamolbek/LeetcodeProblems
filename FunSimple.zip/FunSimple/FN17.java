package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN17 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double a = input.nextDouble();
        double b = input.nextDouble();
        double c = input.nextDouble();
        int n = (int) IldizSoni(a, b, c);
        System.out.println(n);
    }

    static double IldizSoni(double a, double b, double c) {
        double d = b * b - 4 * a * c;
        if (d > 0) return 2;
        else if (d < 0) return 0;
        else return 1;
    }
}
