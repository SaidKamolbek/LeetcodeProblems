package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN22 {
    static double Calc(double a, double b, int c) {
        switch (c) {
            case 1:
                return a - b;
            case 2:
                return a * b;
            case 3:
                return a / b;
            default:
                return a + b;
        }
    }

    public static void main(String[] args) {
        Scanner iput = new Scanner(System.in);
        double a = iput.nextDouble();
        double b = iput.nextDouble();
        int c = iput.nextInt();
        double calc = Calc(a, b, c);
        System.out.println(calc);
    }
}
