package com.GitaEducation.FunSimple;

public class FN43 {
    public static void main(String[] args) {
        double x = 0.5, e = 0.001;
        System.out.println(Ln1(x, e));
        System.out.println(Math.log(x + 1));
    }

    static double Ln1(double x, double e) {
        double q = 1, sum = 0;
        int i = 0;
        while (q / (i + 1) > e) {
            q = Power2(x, i + 1);
            sum += q / (i + 1) * Math.pow(-1, i);
            i++;
        }
        return sum;
    }

    static double Power2(double A, int n) {
        double p = 1;
        if (n == 0) return 1;
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                p *= A;
            }
            return p;
        } else {
            for (int i = 0; i < -n; i++) {
                p *= 1 / A;
            }
        }
        return p;
    }

}
