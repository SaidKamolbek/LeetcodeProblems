package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN9 {
    static int AddLeftDigit(int a, int R){
       int k=0, S=a;
        while (a>0){
            a/=10;
            k++;
        }
        return (int) (R*Math.pow(10,(k))+S);
    }

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        System.out.print("a= ");
        int a= input.nextInt();
        System.out.print("R= ");
        int R= input.nextInt();
        int S=AddLeftDigit(a,R);
        System.out.println(S);
    }
}
