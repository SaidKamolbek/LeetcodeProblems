package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN26 {
    static boolean IsPower5(double k) {
        int d=1;
        while (d<k) d*=5;
        return d==k;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int t = 0;
        for (int i = 0; i < 5; i++) {
            double a= input.nextDouble();
            if (IsPower5(a)) t++;
        }
        System.out.println(t);

    }
}
