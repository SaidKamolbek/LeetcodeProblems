package com.GitaEducation.FunSimple;

public class Fn47 {
    public static void main(String[] args) {
        int a = 24, b = 100, c = 120, d = 80;
        System.out.println(Frac1(a, b));
        System.out.println(Frac1(a, c));
        System.out.println(Frac1(a, d));
    }

    static String Frac1(int a, int b) {
        int p = a / EKUB(a, b);
        int q = b / EKUB(a, b);
        return p + "/" + q;
    }

    static int EKUB(int a, int b) {
        while (a != 0) {
            int q = a;
            a = b % a;
            b = q;
        }
        return b;
    }
}
