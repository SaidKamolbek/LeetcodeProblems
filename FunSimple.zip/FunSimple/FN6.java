package com.GitaEducation.FunSimple;

import java.util.Scanner;

public class FN6 {
    static void DigitCountSUm(int a){
        int k=0, b=0;
        while (a>0){
             b+=a%10;
            a/=10;
            k++;
        }
        System.out.printf("\nraqamlari yigindisi: %d\nraqamlari soni: %d",b,k);
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a= input.nextInt();
        int b= input.nextInt();
        int c= input.nextInt();
        DigitCountSUm(a);
        DigitCountSUm(b);
        DigitCountSUm(c);
    }
}
