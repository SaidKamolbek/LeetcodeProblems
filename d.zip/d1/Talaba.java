package com.Gita2.homewok.d1;

public class Talaba {
    String ism;
    int yil;
    byte kurs;

    void show() {
        System.out.println("\nkirgan yili: " + yil + "\nnechinchi kursda oqiyapti: " + kurs + "\nismi : " + ism);
    }
}
