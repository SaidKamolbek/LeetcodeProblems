package com.Gita2.homewok.d1;

public class TestTalaba {
    public static void main(String[] args) {
        Talaba t1 = new Talaba();
        t1.ism = "saidkamol";
        t1.yil = 2019;
        t1.kurs = 3;
        t1.show();
    }
}
