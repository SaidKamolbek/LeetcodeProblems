package com.Gita2.homewok.d2;

public class Meva {
    String name;
    String type;
    String colour;
    int weight;

    Meva(String name, String type, String colour, int weight) {
        this.name = name;
        this.type = type;
        this.colour = colour;
        this.weight = weight;
    }

    void show() {
        System.out.println("\nname: " + name + "\nfamily: " + type + "\ncolour: " + colour + "\nweight: " + weight);
    }

    boolean hasFruit(int t) {
        return t > weight;
    }
}
