package com.Gita2.homewok.d2;

public class TestMeva {
    public static void main(String[] args) {

        Meva a = new Meva("apple", "pome", "red", 300);
        Meva b = new Meva("granade", "pome", "red", 400);
        Meva c = new Meva("grape", "vitaceae", "green", 200);
        a.show();
        System.out.println(a.hasFruit(300));
        b.show();
        System.out.println(b.hasFruit(200));
        c.show();
        System.out.println(c.hasFruit(300));
    }
}
