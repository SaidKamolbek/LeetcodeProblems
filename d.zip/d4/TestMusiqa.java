package com.Gita2.homewok.d4;

public class TestMusiqa {
    public static void main(String[] args) {
        Musiqa a = new Musiqa("dance", "Ed sheeran", "shape of you");
        Musiqa b = new Musiqa();
        b.setName("Believer");
        b.setType("pop");
        b.setWhose("Imagine Dragons");
        a.show();
        b.show();
    }
}
