package com.Gita2.homewok.d4;

public class Musiqa {
    private String type;
    private String whose;
    private String name;

    Musiqa(String type, String whose, String name) {
        this.type = type;
        this.whose = whose;
        this.name = name;
    }

    Musiqa() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setWhose(String whose) {
        this.whose = whose;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getWhose() {
        return whose;
    }

    void show() {
        System.out.println("\ntype: " + getType() + "\nwhose: " + getWhose() + "\nname: " + getName());
    }
}
