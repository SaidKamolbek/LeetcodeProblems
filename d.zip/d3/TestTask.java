package com.Gita2.homewok.d3;

public class TestTask {
    public static void main(String[] args) {
        Task a = new Task(45, 'a');
        System.out.println(a.getT());
        System.out.println(a.getCh());
    }
}
