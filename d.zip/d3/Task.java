package com.Gita2.homewok.d3;

public class Task {
    private final int t;
    private final char ch;

    Task(int t, char ch) {
        this.t = t;
        this.ch = ch;
    }

    public int getT() {
        return t;
    }

    public char getCh() {
        return ch;
    }
}
