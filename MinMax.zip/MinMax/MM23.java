package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM23 { // max1 yoki max2 boshda kelsa xato ishlab qoladi
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int n = rand.nextInt(50) - 25;
        System.out.print(n + " ");
        int max1=n, max2 = n, max3 = n;
        for (int i = 1; i < N; i++) {
             n = rand.nextInt(50) - 25;
            System.out.print(n + " ");
            if (max1 < n) {
                max3 = max2;
                max2 = max1;
                max1 = n;
            } else if (max2 < n) {
                max3 = max2;
                max2 = n;
            } else if (max3 < n) {
                max3 = n;
            }
//            if (max3<n){
//                if (max2<n){
//                    max3=max2;
//                    if (max1<n){
//                        max2=max1;
//                        max1=n;
//                    }else max2=n;
//                }else max3=n;
//            }
        }
        System.out.printf("\n\n%d \t%d \t%d ", max1,max2, max3);
    }
}

