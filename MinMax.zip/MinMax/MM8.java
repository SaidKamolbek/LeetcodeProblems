package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM8 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int a = rand.nextInt(10) - 5;
        System.out.print(a + " ");
        int minA = a, q = 1, minB = a, p = 1;

        for (int i = 2; i <= N; i++) {
            a = rand.nextInt(11) - 5;
            System.out.print(a + " ");
            if (minA > a) {
                minA = a;
                q = i;
            }
            if (minB >= a) {
                minB = a;
                p = i;
            }
        }
        System.out.println();
        System.out.println(q);
        System.out.println(p);

    }
}
