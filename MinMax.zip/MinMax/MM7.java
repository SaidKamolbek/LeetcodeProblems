package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int a = rand.nextInt(10) - 5;
        System.out.print(a + " ");
        int max = a ,q=1, min = max, p=1;

        for (int i = 2; i <= N; i++) {
            a = rand.nextInt(10) - 5;
            System.out.print(a + " ");
            if (min >= a) {
                min = a;
                q=i;
            }
            if (max < a){
                max = a;
                p=i;
            }
        }
        System.out.println();
        System.out.println(p+"- o`rinda  max: " + max);
        System.out.println(q+"- o`rinda  min: " + min);
    }
}
