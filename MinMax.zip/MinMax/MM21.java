package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM21 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int max = rand.nextInt(10) - 5;
        System.out.print(max + " ");
        int min = max, S = max, q = 1, k = 1;
        for (int i = 1; i < N; i++) {
            int n = rand.nextInt(10) - 5;
            System.out.print(n + " ");
            S += n;
            if (min > n) {
                min = n;
                k = 1;
            } else if (min == n) k++;

            if (max < n) {
                max = n;
                q = 1;
            } else if (max == n) q++;
        }
        S -= q * max + k * min;
        System.out.printf("\nmax: %d >> %dta \nmin: %d >> %dta  \no`rtacha:  %.2f", max,q, min,k, (double) S / (N - k - q));
    }
}
