package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM12 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random r = new Random();
        int N = input.nextInt();
        int min = 0;
        boolean k = true;
        //  System.out.print(min + " ");
        for (int i = 0; i < N; i++) {
            int a = r.nextInt(10) - 5;
            System.out.print(a + " ");
            if (a > 0) {
                if (min > a) min = a;
                else if (k) {
                    min = a;
                    k = false;
                }
            }
        }
        System.out.println();
        System.out.println(min);
    }
}
