package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM19 { // xato
    public static void main(String[] args) {
        Scanner inpu = new Scanner(System.in);
        Random rand = new Random();
        int N = inpu.nextInt();
        int min = rand.nextInt(10) - 5;
        System.out.print(min + " ");
        int k = 0;
        for (int i = 1; i < N; i++) {
            int n = rand.nextInt(10) - 5;
            System.out.print(n + " ");
            if (min > n) {
                min = n;
                k = 1;
            } else if (min == n) k++;
        }
        System.out.println();
        System.out.println(k + " ta");
        System.out.println(min);
    }
}
