package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM9 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int a = rand.nextInt(10) - 5;
        System.out.print(a + " ");
        int maxA = a, q = 1, maxB = a, p = 1;

        for (int i = 2; i <= N; i++) {
            a = rand.nextInt(11) - 5;
            System.out.print(a + " ");
            if (maxA < a) {
                maxA = a;
                q = i;
            }
            if (maxB <= a) {
                maxB = a;
                p = i;
            }
        }
        System.out.println();
        System.out.println(q);
        System.out.println(p);
    }
}
