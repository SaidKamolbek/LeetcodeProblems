package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int a = rand.nextInt(10) - 5;
        System.out.print(a + " ");
        int min = a, q = 1, max = a, p = 1;

        for (int i = 2; i <= N; i++) {
            a = rand.nextInt(11) - 5;
            System.out.print(a + " ");
            if (min > a) {
                min = a;
                q = i;
            }
            if (max < a) {
                max = a;
                p = i;
            }
        }
        System.out.println();
        if (q > p) {
            System.out.println(p);
        } else System.out.println(q);
    }
}
