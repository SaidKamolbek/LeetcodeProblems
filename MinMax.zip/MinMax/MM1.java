package com.GitaEducation.MinMax;

import java.util.Scanner;

public class MM1 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int N= input.nextInt();
        int min= input.nextInt();
        int max=min;
        for (int i = 1; i <N; i++) {
            int a= input.nextInt();
            if (min>a)min=a;
            if (max<a)max=a;
        }
        System.out.println(max);
        System.out.println(min);
    }
}
