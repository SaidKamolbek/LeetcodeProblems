package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM25 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int n = rand.nextInt(50) - 25;
        System.out.print(n + " ");
        int a2 = n, a1 = 0, min = Integer.MAX_VALUE, k = 0, q = 0;
        for (int i = 2; i <= N; i++) {
            n = rand.nextInt(50) - 25;
            System.out.print(n+" ");
            a1=a2;
            a2=n;
            if (min>a2*a1){
                min=a2*a1;
                q=i-1;
                k=i;
            }
        }        System.out.printf(" \n%d\tva\t%d \nyigindis: %d", q, k, min);

    }
}
