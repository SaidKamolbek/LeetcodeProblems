package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM16 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand= new Random();
        int N= input.nextInt();
        int min= rand.nextInt(50), k=0;
        System.out.print(min+" ");
        for (int i = 1; i < N; i++) {
            int n= rand.nextInt(50);
            System.out.print(n+" ");
            if (min>n){
                min=n;
                k=i;
            }
        }
        System.out.println();
        System.out.println(k+"ta element bor");
        System.out.print("min: "+min);
    }
}
