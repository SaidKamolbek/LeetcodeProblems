package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM17 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand= new Random();
        int N= input.nextInt();
        int max= rand.nextInt(50)-25, k=1;
        System.out.print(max+" ");

        for (int i = 2; i <= N; i++) {
            int n= rand.nextInt(50)-25;
            System.out.print(n+" ");
            if (max<=n){
                max=n;
                k=i;
            }
        }
        System.out.println();
        System.out.println(N-k);
        System.out.println(max);
    }
}
