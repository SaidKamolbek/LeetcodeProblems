package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM15 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int B = input.nextInt();
        int C = input.nextInt();
        int max = 0, k = 0;
        boolean t = true;
        for (int i = 1; i <= 10; i++) {
            int n = rand.nextInt(50) - 24;
            System.out.print(n + " ");
            if (n > B && n < C) {
                if (max < n) {
                    max = n;
                    k = i;
                } else if (t) {
                    max = n;
                    t = false;
                    k = i;
                }
            }
        }
        //    System.out.printf("%. k= %d max=  %d ", k, max);
        System.out.println();
        System.out.println(k);
        System.out.println(max);
    }
}
