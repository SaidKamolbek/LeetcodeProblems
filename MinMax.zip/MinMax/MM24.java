package com.GitaEducation.MinMax;

import com.sun.jdi.Value;

import javax.swing.text.Style;
import java.util.Random;
import java.util.Scanner;

public class MM24 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int n = rand.nextInt(50)-25;
        System.out.print(n + " ");
        int a2 = n, a1 = n, max = Integer.MIN_VALUE, k=0, q=0;
        for (int i = 1; i < N; i++) {
            n = rand.nextInt(50)-25;
            System.out.print(n + " ");
            a1 = a2;
            a2 = n;
            if (max < a2 + a1){
                max = a2 + a1;
                k=a1;
                q=a2;
            }
        }
        System.out.printf(" \n%d\tva\t%d \nyigindis: %d", k, q, max);
    }
}
