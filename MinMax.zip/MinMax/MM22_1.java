package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM22_1 {  // eng kicik elementni o`zi 2ta bo`p qolsa  min1=min2 bo`p qoladi
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int min1 = rand.nextInt(50) - 25;
        System.out.print(min1 + " ");
        int min2 = min1;
        for (int i = 1; i < N; i++) {
            int n = rand.nextInt(50) - 25;
            System.out.print(n + " ");
            if (min1 > n) {
                min2 = min1;
                min1 = n;
            } else if (min2 > n) {
                min2 = n;
            }
        }
        System.out.printf("\nmin1: %d  \nmin2: %d", min1, min2);

    }
}

class MM22_2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int min1 = rand.nextInt(50) - 25;
        System.out.print(min1 + " ");
        int min2 = min1;
        for (int i = 1; i < N; i++) {
            int n = rand.nextInt(50) - 25;
            System.out.print(n+" ");
            if (min2 > n) {
                min2 = min1;
                if (min1 > n) {
                    min1 = n;
                } else min2 = n;
            }
        }
        System.out.printf("\nmin1: %d  \nmin2: %d", min1, min2);

    }
}