package com.GitaEducation.MinMax;

import java.awt.*;
import java.util.Random;
import java.util.Scanner;

public class MM2 {
    public static void main(String[] args) {
        Random random=new Random();
        Scanner input=new Scanner(System.in);
        int N= input.nextInt(), S=1;
        int a= random.nextInt(100);
        int b= random.nextInt(100);
        System.out.println(a+" "+b);
        int min=a*b;
        for (int i = 2; i <=N ; i++) {
             a= random.nextInt(100);
             b= random.nextInt(100);
            System.out.println(a+" "+b);
            if (min>a*b){
                min=a*b;
                S=i;
            }

        }
        System.out.print(S+"- to`rtburchak: ");
        System.out.println(min);
    }
}
