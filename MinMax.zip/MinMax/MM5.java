package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int m = rand.nextInt(100);
        int v = rand.nextInt(100);
        double max = (double) m / v, S = 0;
        System.out.println(m + " " + v);
        for (int i = 2; i <= N; i++) {
            m = rand.nextInt(100);
            v = rand.nextInt(100);
            System.out.println(m + " " + v);
            if (max < (double) m / v) {
                max = (double) m / v;
                S = i;
            }
        }
        System.out.print(S + "-element: " + max);

    }
}
