package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int a= rand.nextInt(100);
        System.out.print(a+" ");
        int S=1,min=a;
        for (int i = 2; i <=N ; i++) {
            a= rand.nextInt(100);
            System.out.print(a+" ");
            if (min>a){
                min=a;
                S=i;
            }
        }
        System.out.println();
        System.out.println(S+"-element : "+min);
    }
}
