package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int S = 1;
        int N = input.nextInt();
        int a = rand.nextInt(100)+1;
        int b = rand.nextInt(100)+1;
        System.out.println(a + " " + b);
        int maxP = 2 * (a + b);
        for (int i = 2; i <= N; i++) {
            a = rand.nextInt(100) + 1;
            b = rand.nextInt(100) + 1;
            System.out.println(a + " " + b);
            if (maxP < 2 * (a + b)) {
                maxP = 2 * (a + b);
                S = i;
            }
        }
        System.out.print(S + "- to`rtburchak: ");
        System.out.println(maxP);
    }
}
