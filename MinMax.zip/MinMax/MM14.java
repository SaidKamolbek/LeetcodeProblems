package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM14 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int B = input.nextInt();
        boolean t = true;
        int min = 0, k = 0;
        for (int i = 1; i <= 10; i++) {
            int n = rand.nextInt(50) - 25;
            System.out.print(n + " ");
            if (B < n) {
                if (min > n) {
                    min = n;
                    k = i;
                } else if (t) {
                    min = n;
                    t = false;
                    k=i;
                }
            }
        }
        System.out.println();
        System.out.println(k);
        System.out.println(min);
    }
}
