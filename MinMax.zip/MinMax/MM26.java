package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM26 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int n = rand.nextInt(50) - 25;
        System.out.print(n + " ");
        int a2 = n, a1 = 0,k=0;
        for (int i = 1; i <N ; i++) {
            n= rand.nextInt(50)-25;
            System.out.print(n+" ");
            a1=a2;
            a2=n;
            if (a1%2==0 && a2%2==0)k++;
        }
        System.out.printf("\n%d",k);
    }
}
