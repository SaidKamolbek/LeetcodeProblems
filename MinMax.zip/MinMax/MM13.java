package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM13 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int max = 0;
        boolean k = true;
        for (int i = 0; i < N; i++) {
            int n = rand.nextInt(10)-5;
            System.out.print(n + " ");
            if (n % 2 == 1) {
                if (max < n) max = n;
                else if (k) {
                    max = n;
                    k = false;
                }
            }
        }
        System.out.println();
        System.out.println(max);
    }
}
