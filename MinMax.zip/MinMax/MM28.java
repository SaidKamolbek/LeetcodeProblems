package com.GitaEducation.MinMax;

import java.util.Random;
import java.util.Scanner;

public class MM28 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int N = input.nextInt();
        int n = rand.nextInt(2) ;
        System.out.print(n + " ");
        int a2 = n, a1 = 0, f=0, k = 0,q=0, max=0;
        for (int i = 2; i <= N; i++) {
            n= rand.nextInt(2);
            System.out.print(n+" ");
            f=a1;
            a1=a2;
            a2=n;
            if (a1==a2&& a1==1){
                if (a1!=f)k=1;
                k++;
            }
            if (max<k){
                max=k;
                q=i-k+1;
            }
        }
        System.out.printf("\n%d ta element \n%d-qatordan boshlanadi",max,q);
    }
}
