package com.GitaEducation.For;

import java.util.Scanner;

public class For35 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int n= input.nextInt();
        int [] a=new int[n];
        a[0]=1;a[1]=2;a[2]=3;
        for (int i = 3; i <n ; i++) {
            a[i]=a[i-1]+a[i-2]-2*a[i-3];
            System.out.println(a[i]+" ");
        }
    }
}
