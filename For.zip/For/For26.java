package com.GitaEducation.For;

import java.util.Scanner;

public class For26 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        double x= in.nextDouble();
        double S=0;
        for (int i = 1; i <=n ; i++) {
            S+=Math.pow(-1,i)*Math.pow(x,2*i+1)/(2*i+1);
        }
        System.out.println(S);
    }
}
