package com.GitaEducation.For;

import java.util.Scanner;

public class For22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double x= in.nextDouble();
        double S=1, P=1;
        for (int i = 1; i <=n ; i++) {
            P*=i;
            S+=Math.pow(x,i)/P;
        }
        System.out.println(S);
    }
}
