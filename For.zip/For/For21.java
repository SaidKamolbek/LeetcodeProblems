package com.GitaEducation.For;

import java.util.Scanner;

public class For21 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double P = 1, S=0;
        for (double i = 1; i <= n; i++) {
            P *= i;
            S+=1/P;

        }
        System.out.println(S);
    }
}
