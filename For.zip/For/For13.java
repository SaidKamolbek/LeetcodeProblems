package com.GitaEducation.For;

import java.util.Scanner;

public class For13 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        double S=0, q=1.1;
        for (int i = 0; i < n; i++) {
            S+=q*Math.pow(-1,i);
            q+=0.1;
        }
        System.out.println(S);
    }
}
