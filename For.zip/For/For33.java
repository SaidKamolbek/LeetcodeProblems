package com.GitaEducation.For;

import java.util.Scanner;

public class For33 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        int[] a=new int[n];
       a[1]=1;a[2]=1;
        for (int i = 3; i < n; i++) {
            a[i]=a[i-1]+a[i-2];
        }
        for (int i = 1; i < n; i++) {
            System.out.print(a[i]+" ");
        }
    }
}
