package com.GitaEducation.For;

import java.util.Scanner;

public class For31 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double A0=2 ;
        for (int i = 1; i < n; i++) {
            A0=2+1/A0;
            System.out.print(A0+" ");
        }

    }
}
