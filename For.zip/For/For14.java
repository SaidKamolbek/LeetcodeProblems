package com.GitaEducation.For;

import java.util.Scanner;

public class For14 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        int kv=0;
        for (int i = 1; i <= 2*n-1; i+=2) {
            kv+=i;
        }
        System.out.println(kv);
    }
}
