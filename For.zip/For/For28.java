package com.GitaEducation.For;

import java.util.Scanner;

public class For28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double x = in.nextDouble();
        double S = 1, q = -1, p = 1;
        for (int i = 1; i < n; i++) {
            q*=2*i-3;
            p*=2*i;
            S+=Math.pow(-1,i-1)*q*Math.pow(x,i)/p;
        }
        System.out.println(S);
    }
}
