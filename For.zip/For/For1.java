package com.GitaEducation.For;

import java.util.Scanner;

public class For1 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        int k= in.nextInt();
        for (int i = 0; i < k; i++) {
            System.out.print(n+" ");
        }
    }
}
