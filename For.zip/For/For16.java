package com.GitaEducation.For;

import java.util.Scanner;

public class For16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int n = in.nextInt();
        int P = 1;
        for (int i = 0; i < n; i++) {
            P *= a;
            System.out.print(P+" ");
        }
    }
}
