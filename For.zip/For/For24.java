package com.GitaEducation.For;

import javax.swing.*;
import java.util.Scanner;

public class For24 {
    public static void main(String[] args) {
        Scanner in= new Scanner(System.in);
        int n= in.nextInt();
        double x= in.nextDouble();
        double S=1, P=1;
        for (int i = 1; i <n ; i++) {
            P*=i;
            if (i%2==1)continue;
            S+= Math.pow(-1,i/2)*Math.pow(x,i)/P;
        }
        System.out.println(S);
    }
}
