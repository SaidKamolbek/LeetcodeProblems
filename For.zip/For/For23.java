package com.GitaEducation.For;

import java.util.Scanner;

public class For23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double x = in.nextDouble();
        double S = 0, P = 1, q = 1;
        for (int i = 1; i < n; i++) {
            P *= i;
            if (i % 2 == 0) continue;
            S += Math.pow(-1, i / 2) * Math.pow(x, i) / P;
        }
        System.out.println(S);
    }
}
