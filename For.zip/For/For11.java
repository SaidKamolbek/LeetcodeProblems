package com.GitaEducation.For;

import java.util.Scanner;

public class For11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int S = 0;
        for (int i = n; i <= n * n; i++) {
            S+=i*i;
        }
        System.out.println(S);
    }
}
