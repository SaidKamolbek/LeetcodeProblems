package com.GitaEducation.For;

import java.util.Scanner;

public class For29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double A = in.nextDouble();
        double B = in.nextDouble();
        double  d = 0;
        d = (B-A) / n;
        for (double i = 0; i < n; i++) {
            A += d;
            System.out.println(A);
        }
    }
}
