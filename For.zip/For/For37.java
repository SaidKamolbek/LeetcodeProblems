package com.GitaEducation.For;

import java.util.Scanner;

public class For37 {
    public static void main(String[] args) {
        Scanner init = new Scanner(System.in);
        int n = init.nextInt();
        int S = 0;;
        for (int i = 1; i <= n; i++) {
            int p = 1;
            for (int j = 1; j <= i; j++) {
                p*=i;
            }
            S+=p;
            System.out.print(p+" ");
        }
        System.out.println();
        System.out.println(S);
    }
}
