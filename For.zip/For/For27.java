package com.GitaEducation.For;

import java.util.Scanner;

public class For27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double x = in.nextDouble();
        double S = x, q = 1, p = 1;
        for (int i = 1; i < n; i++) {
            q *= 2 * i - 1;
            p *= 2*i;
            S+=q*Math.pow(x,2*i+1)/(p*(2*i+1));
        }
        System.out.println(S);
    }
}
