package com.GitaEducation.For;

import java.util.Scanner;

public class For12 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        double D=1,d=1.1;
        for (int i = 1; i <=n ; i++) {
            D*=d;
            d+=0.1;
        }
        System.out.println(D);
    }
}
