package com.GitaEducation.For;

import java.util.Scanner;

public class For36 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int N = input.nextInt();
        int K = input.nextInt();
        int S = 0;
        for (int i = 1; i <= N; i++) {
            int p = 1;
            for (int j = 1; j <= K; j++) {
                p *= i;
            }
            System.out.print(p + " + ");
            S += p;
        }
        System.out.println("= "+S);
    }
}
