package com.GitaEducation.For;

import java.util.Scanner;

public class For2 {
    public static void main(String[] args) {
        Scanner in= new Scanner(System.in);
        int a= in.nextInt();
        int b= in.nextInt();
        int S=0;
        for (int i = a; i <=b ; i++) {
            System.out.print(i+" ");
            S++;
        }
        System.out.println();
        System.out.println(S+"ta");
    }
}
