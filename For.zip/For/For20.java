package com.GitaEducation.For;

import java.util.Scanner;

public class For20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int P = 1, S=0;
        for (int i = 1; i <= n; i++) {
            P *= i;
            S+=P;

        }
        System.out.println(S);
    }
}
