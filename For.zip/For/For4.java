package com.GitaEducation.For;

import java.util.Scanner;

public class For4 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int a= in.nextInt();
        for (int i = 1; i <=10; i++) {
            int S=a*i;
            System.out.println(S+" so`m");
        }
    }
}
