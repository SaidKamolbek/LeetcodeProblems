package com.GitaEducation.For;

import java.util.Scanner;

public class For38 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        int S=0;
        for (int i = 1; i <=n ; i++) {
            int p=1;
            for (int j = n; j >=i ; j--) {
                p*=i;
            }
            S+=p;
            System.out.print(p+" ");
        }
        System.out.println();
        System.out.println(S);
    }
}
