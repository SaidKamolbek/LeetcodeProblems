package com.GitaEducation.For;

import java.util.Scanner;

public class For18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        int n = in.nextInt();
        int P = 1, S=1;
        for (int i = 1; i <= n; i++) {
            P *= a;
            S+=P*Math.pow(-1,i);
        } System.out.println(S);
    }
}
