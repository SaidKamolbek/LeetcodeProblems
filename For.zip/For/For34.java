package com.GitaEducation.For;

import java.util.Scanner;

public class For34 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double[] a = new double[n];
        a[1] = 1;
        a[2] = 2;
        for (int i = 3; i < n; i++) {
            a[i] = (a[i - 2] + 2 * a[i - 1]) / 3;
        }
        for (int i = 1; i < n; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
