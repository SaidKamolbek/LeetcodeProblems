package com.GitaEducation.For;

import java.util.Scanner;

public class For32 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n= in.nextInt();
        double A=1;
        for (int i = 1; i <=n ; i++) {
        A=(A+1)/i;
            System.out.print(A+" ");
        }
    }
}
