package com.GitaEducation.For;

import java.util.Scanner;

public class For40 {
    public static void main(String[] args) {
        Scanner init=new Scanner(System.in);
        int A= init.nextInt();
        int B= init.nextInt();
        for (int i = A; i <= B; i++) {
            for (int j = A; j <=i ; j++) {
                System.out.print(i+" ");
            }
        }
    }
}
