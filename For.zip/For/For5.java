package com.GitaEducation.For;

import java.util.Scanner;

public class For5 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        double a= in.nextDouble();
        for (double i = 0; i <=1; i+=0.1) {
            double S=a*i;
            System.out.println(S+" som`");
        }
    }
}
